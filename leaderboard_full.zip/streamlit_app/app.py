import streamlit as st
from .auth import signin, signup, send_password_reset
from .firebase import admin_emails
from .ui_student import student_view
from .ui_admin import admin_view

st.set_page_config(page_title="Class Leaderboard", page_icon="🏁", layout="wide")

def login_box():
    tab_login, tab_signup, tab_reset = st.tabs(["Login","Register","Reset Password"])
    with tab_login:
        email = st.text_input("Email")
        pw = st.text_input("Password", type="password")
        if st.button("Login", type="primary"):
            data, err = signin(email, pw)
            if err:
                st.error(err)
            else:
                st.session_state.user = {"email": data["email"]}
                st.rerun()
    with tab_signup:
        email = st.text_input("Uni Email (domain restricted)", key="su_email")
        pw = st.text_input("Password", type="password", key="su_pw")
        if st.button("Register"):
            data, err = signup(email, pw)
            if err:
                st.error(err)
            else:
                st.success("Registered. Please login."); st.experimental_rerun()
    with tab_reset:
        email = st.text_input("Email for reset", key="rp_email")
        if st.button("Send reset link"):
            ok = send_password_reset(email)
            st.success("If the email exists, a reset link was sent." if ok else "Failed to send reset.")

def main():
    st.title("🏁 Class Leaderboard")
    user = st.session_state.get("user")
    if not user:
        login_box()
        st.stop()

    is_admin = user["email"].lower() in admin_emails()
    view = st.sidebar.radio("View", ["Student","Admin"] if is_admin else ["Student"])
    if view == "Student":
        student_view(user)
    else:
        admin_view(user)

    if st.sidebar.button("Logout"):
        st.session_state.clear(); st.experimental_rerun()

if __name__ == "__main__":
    main()
