import streamlit as st
from . import data
from .models import Category
from datetime import datetime

CATEGORIES_POOL = [
    ("clarity","Clarity & Structure"),
    ("evidence","Evidence & Examples"),
    ("creativity","Creativity / Originality"),
    ("delivery","Delivery & Presence"),
    ("visuals","Visual Design / Slides"),
    ("techdepth","Technical Depth"),
    ("story","Storytelling / Narrative"),
    ("persuasion","Persuasion / Call-to-Action"),
]

def admin_view(user):
    st.header("Admin — Control Panel")

    st.subheader("Classes")
    classes = data.list_classes()
    cols = st.columns(2)
    with cols[0]:
        class_id = st.selectbox("Select class", [c["id"] for c in classes] if classes else [], format_func=lambda i: next(c["name"] for c in classes if c["id"]==i))
    with cols[1]:
        new_name = st.text_input("New class name")
        if st.button("Create Class"):
            if new_name:
                from .firebase import get_db
                db = get_db()
                ref = db.collection("classes").document()
                ref.set({"id":ref.id,"name":new_name,"archived":False,"createdAt":datetime.utcnow()})
                st.success("Class created"); st.rerun()

    if not class_id:
        st.stop()

    st.subheader("Sessions")
    sessions = data.list_sessions(class_id)

    with st.expander("Create Session"):
        title = st.text_input("Title")
        desc = st.text_area("Description")
        weighting = st.slider("Teacher weighting (%)", 0, 100, 50)
        allow_edits = st.toggle("Allow edits until close", True)
        grace = st.number_input("Grace minutes", 0, 10, 0)

        st.caption("Pick 4–5 categories")
        chosen = st.multiselect("Categories", CATEGORIES_POOL, default=CATEGORIES_POOL[:5], format_func=lambda t: t[1])
        if st.button("Create Session", type="primary"):
            cats = [Category(id=k,label=v).model_dump() for (k,v) in chosen]
            payload = {
                "title": title or f"Session {len(sessions)+1}",
                "description": desc,
                "tags": [],
                "categories": cats,
                "weighting": {"teacherPct": weighting, "peersPct": 100 - weighting},
                "status": "scheduled",
                "allowEditsUntilClose": allow_edits,
                "graceMinutes": int(grace),
            }
            created = data.create_session(class_id, payload)
            st.success(f"Created session {created['title']}")

    st.subheader("Open/Close Session")
    if sessions:
        pick = st.selectbox("Session", [s["id"] for s in sessions], format_func=lambda i: next(s["title"] for s in sessions if s["id"]==i))
        s = next(s for s in sessions if s["id"]==pick)
        st.write(f"Status: **{s['status']}**")
        cols = st.columns(3)
        with cols[0]:
            if st.button("Open"):
                data.set_session_status(class_id, pick, "open"); st.rerun()
        with cols[1]:
            if st.button("Close"):
                data.set_session_status(class_id, pick, "closed"); st.rerun()
        with cols[2]:
            if st.button("Archive"):
                data.set_session_status(class_id, pick, "archived"); st.rerun()
