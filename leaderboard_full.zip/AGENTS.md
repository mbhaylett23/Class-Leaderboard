# AGENTS.md — Project Guardrails (Read me first)

**Project:** Class Leaderboard with live voting, teacher/peer weighting, admin console, archives.  
**Stack:** Streamlit UI, Firebase Auth (email/password), Firestore DB.

## Principles
1) Thin-slice work: one narrow outcome per task.
2) UI-first then logic: build layouts/hierarchy with placeholders before wiring data.
3) Minimal diffs: touch the smallest file set needed; keep changes under ~60 LOC where possible.
4) Modularity & file hygiene: UI in `ui_*.py`, logic in `data.py`, Firestore client in `firebase.py`, models in `models.py`.
5) Tests as contract: update/add tests in `tests/` matching acceptance criteria.
6) Durable, short context: every task starts with the template in `docs/SPRINT_NOTES.md`.
7) No scope creep: new ideas go into `docs/BACKLOG.md`.

## Directory rules
```
streamlit_app/
  app.py                # routing + auth + view switch
  ui_student.py         # student UI
  ui_admin.py           # admin UI
  data.py               # Firestore CRUD + aggregations (pure funcs)
  firebase.py           # Firestore client (service account from secrets)
  models.py             # Pydantic models
  .streamlit/
    secrets.TEMPLATE.toml
docs/
  SPRINT_NOTES.md
  BACKLOG.md
  WIREFRAMES/
tests/
  test_scoring.py
  test_rules.py
README.md
requirements.txt
```

## Coding conventions
- Python 3.11+, Streamlit 1.36+.
- Keep functions ≤50 LOC when possible; prefer pure functions for scoring.
- Secrets only via `st.secrets` (cloud) or `.env` (local). Never hardcode.

## Claude/Copilot/Cursor — Do this first
- Show a **patch plan** before coding: list files to touch and why.
- Ask **one clarifying question** if uncertain, then proceed.
- Keep diffs minimal; do not move files unless explicitly asked.
- Respect **No-go zones** listed in each task.
