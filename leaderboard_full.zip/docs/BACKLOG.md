# BACKLOG.md

- Roster CSV import + approval queue
- Presenting-team dropdown + self-vote block
- Export CSV (session/team/student/audit)
- Archive view (read-only past sessions)
- Emoji overlay + “super vote” (+5)
- Auto-close timer; confetti/delta arrows
- Analytics dashboard (participation, deltas, trends)
